﻿using SnippetCLI;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text.Json;

class Program
{
    static void Main()
    {
        Console.WriteLine("Code Snippet Manager");

        while (true)
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("\n1. Add a new code snippet");
            Console.WriteLine("2. List all code snippet options");
            Console.WriteLine("3. List all code snippets fully");
            Console.WriteLine("4. Get a specific code snippet");
            Console.WriteLine("5. Delete a code snippet");
            Console.WriteLine("6. Exit");

            Console.Write("Choose an option: ");
            string choice = Console.ReadLine();

            switch (choice)
            {
                case "1":
                    AddSnippet();
                    break;
                case "2":
                    ListSnippetOptions();
                    break;
                case "3":
                    ListSnippets();
                    break;
                case "4":
                    GetSnippet();
                    break;
                case "5":
                    DeleteSnippet();
                    break;
                case "6":
                    Environment.Exit(0);
                    break;
                default:
                    Console.WriteLine("Invalid option. Please try again.");
                    break;
            }
        }
    }

    private static void ListSnippetOptions()
    {
        Console.WriteLine("List of Snippet Options:");

        foreach (var file in Directory.GetFiles(Directory.GetCurrentDirectory(), "*.json"))
        {
            string json = File.ReadAllText(file);
            var snippet = JsonSerializer.Deserialize<Snippet>(json);

            Console.WriteLine($"Title: {snippet.Title}");
        }
    }

    static void AddSnippet()
    {
        Console.Write("Enter snippet title: ");
        string title = Console.ReadLine();

        Console.WriteLine("Enter code snippet:");
        string code = Console.ReadLine();

        Console.WriteLine("Enter language (press Ctrl+Z on a new line to finish):");  
        string language = Console.In.ReadToEnd();

        var snippet = new Snippet { Title = title, Code = code, Language = language };

        string json = JsonSerializer.Serialize(snippet);

        File.WriteAllText($"{title}.json", json);

        Console.WriteLine("Snippet added successfully!");
    }

    static void ListSnippets()
    {
        Console.WriteLine("List of Snippets:");

        foreach (var file in Directory.GetFiles(Directory.GetCurrentDirectory(), "*.json"))
        {
            string json = File.ReadAllText(file);
            var snippet = JsonSerializer.Deserialize<Snippet>(json);

            Console.WriteLine($"Title: {snippet.Title}");
            Console.WriteLine($"Code:\n{snippet.Code}\n");
            Console.WriteLine($"Language: {snippet.Language}\n");
        }
    }

    static void GetSnippet()
    {
        Console.Write("Enter snippet title: ");
        string title = Console.ReadLine();
         mn
        try
        {
            string json = File.ReadAllText($"{title}.json");
            var snippet = JsonSerializer.Deserialize<Snippet>(json);
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine($"\nTitle: {snippet.Title}\n");
            Console.WriteLine($"Code:\n{snippet.Code}\n");
            Console.WriteLine($"Language: {snippet.Language}");
        }
        catch (FileNotFoundException)
        {
            Console.WriteLine("Snippet not found.");
            return;
        }
    }

    static void DeleteSnippet()
    {
        Console.WriteLine("Enter a snippet title to delete: ");
        string title = Console.ReadLine();

        try
        {
            File.Delete($"{title}.json");
            Console.WriteLine("Snippet deleted successfully!");
        }
        catch (FileNotFoundException)
        {
            Console.WriteLine("Snippet not found.");
            return;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SnippetCLI
{
    [Serializable]
    public class Snippet
    {
        public string Title { get; set; }
        public string Code { get; set; }

        public string Language { get; set; }

    }
}
